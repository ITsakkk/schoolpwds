function toggleAnswer(element) {
    const answer = element.nextElementSibling;
    const icon = element.querySelector("span");

    if (answer.style.display === "block") {
        answer.style.display = "none";
        icon.textContent = "+";
        element.classList.remove("active"); // Remove active class
    } else {
        answer.style.display = "block";
        icon.textContent = "-";
        element.classList.add("active"); // Add active class
    }
}
function toggleDetails(img) {
    const parent = img.parentElement;
    const boxTitle = parent.querySelector(".box-title-1, .box-title-2");
    boxTitle.style.transform =
      boxTitle.style.transform === "translateY(100%)"
        ? "translateY(0)"
        : "translateY(100%)";
  }
  